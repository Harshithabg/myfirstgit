package com.lti.CollegeDatabase;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Instructor30")
public class Instructor {
	private long inst_id;
	private String inst_name;
	private long phone_no;
	private long Room_no;

	private Department department;
	
	public Instructor() {
		
	}
	
	public Instructor(String inst_name, long phone_no, long room_no, Department department) {
		super();
		this.inst_name = inst_name;
		this.phone_no = phone_no;
		Room_no = room_no;
		this.department = department;
	}
@Id
@Column(name="Inst_id")
@GeneratedValue(strategy=GenerationType.AUTO,generator="somesequenceName")
@SequenceGenerator(name="somesequenceName",sequenceName="inst_seq20",allocationSize =1)

public long getInst_id() {
	return inst_id;
}

public void setInst_id(long inst_id) {
	this.inst_id = inst_id;
}
@Column(name="Inst_name")
public String getInst_name() {
	return inst_name;
}

public void setInst_name(String inst_name) {
	this.inst_name = inst_name;
}
@Column(name="Inst_phone")
public long getPhone_no() {
	return phone_no;
}

public void setPhone_no(long phone_no) {
	this.phone_no = phone_no;
}
@Column(name="Inst_room")
public long getRoom_no() {
	return Room_no;
}

public void setRoom_no(long room_no) {
	Room_no = room_no;
}
	


@Override
public String toString() {
	return "Instructor [inst_id=" + inst_id + ", inst_name=" + inst_name + ", phone_no=" + phone_no + ", Room_no="
			+ Room_no + ", department=" + department + "]";
}

}






