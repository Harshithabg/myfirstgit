
package com.lti.Mapping.OneToMany;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("persistence");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        
        System.out.println("Starting Transaction");
        entityManager.getTransaction().begin();
        
        Department department = new Department("JAVA","BANGALORE");
        Employee emp1 =new Employee("harshitha",111200,department);
        Employee emp2 =new Employee("vicky",121200,department);
        Employee emp3 =new Employee("mukul",131200,department);
        
        Set<Employee> emp=new HashSet<Employee>();
        emp.add(emp1);
        emp.add(emp2);
        emp.add(emp3);
        
        
        department.setEmployees(emp);
        
        entityManager.getTransaction().commit();
        entityManager.close();
        
        
        
        
        
        
    }
}