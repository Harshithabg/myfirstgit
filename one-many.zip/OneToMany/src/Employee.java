
package com.lti.Mapping.OneToMany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {
	private long emp_id;
	private String emp_name;
	private int salary;
	
	
	private Department department;
	
	public Employee() {
		
	}
	
	



public Employee(String emp_name, int salary, Department department) {
		super();
		this.emp_name = emp_name;
		this.salary = salary;
		this.department = department;
	}





@Id
@Column(name="EMP_ID")
@GeneratedValue
	
public long getEmp_id() {
	return emp_id;
}

public void setEmp_id(long emp_id) {
	this.emp_id = emp_id;
}
public String getEmp_name() {
	return emp_name;
}

public void setEmp_name(String emp_name) {
	this.emp_name = emp_name;
}

public int getSalary() {
	return salary;
}

public void setSalary(int salary) {
	this.salary = salary;
}

@ManyToOne
@JoinColumn(name="Dept_id")
	
public Department getDepartment() {
	return department;
}

public void setDepartment(Department department) {
	this.department = department;
}





@Override
public String toString() {
	return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", salary=" + salary + ", department=" + department
			+ "]";
}




	

}