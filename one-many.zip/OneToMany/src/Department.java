package com.lti.Mapping.OneToMany;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="department60")
public class Department {
	
	private long dept_id;
	private String dept_name;
	private String location;
	
	private Set<Employee> employees;
	
	public Department() {
		
	}
public Department(String dept_name, String location) {
		super();
		this.dept_name = dept_name;
		this.location = location;
		
	}
@Id
@Column(name="Dept_id")
@GeneratedValue
public long getDept_id() {
	return dept_id;
}

public void setDept_id(long dept_id) {
	this.dept_id = dept_id;
}

public String getDept_name() {
	return dept_name;
}

public void setDept_name(String dept_name) {
	this.dept_name = dept_name;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

	
@OneToMany(mappedBy="department",cascade=CascadeType.ALL)
public Set<Employee> getEmployees() {
	return employees;
}

public void setEmployees(Set<Employee> employees) {
	this.employees = employees;
}

@Override
public String toString() {
	return "Department [dept_id=" + dept_id + ", dept_name=" + dept_name + ", location=" + location + "]";
}
}