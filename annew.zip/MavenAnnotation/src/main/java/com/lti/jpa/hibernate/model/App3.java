package com.lti.jpa.hibernate.model;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App3 {
	public static void main(String[] args){
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		Scanner sc=new Scanner(System.in);
		entityManager.getTransaction().begin();
		System.out.println("starting trancation");
		Address ad = new Address();
		System.out.println("Enter city :");
		String city=sc.next();
		ad.setCity(city);
		System.out.println("Enter country :");
		String country=sc.next();
		ad.setCountry(country);
		
		Student st = new Student();
		System.out.println("Enter first name :");
		String fname=sc.next();
		st.setFname(fname);
		System.out.println("Enter last name :");
    	String lname=sc.next();
	    st.setLname(lname);
	    System.out.println("Enter section :");
    	String sec=sc.next();
    	st.setSection(sec);
	   
    	st.setAddress(ad);
    	ad.setStudent(st);
    	
		
		entityManager.persist(st);
		entityManager.persist(ad);
		System.out.println("saving  to database");
		
		entityManager.getTransaction().commit();
		System.out.println("successfully added to db");
		 
		 entityManager.close();
		  entityManagerFactory.close();
}
}
