package com.lti.jpa.hibernate.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT20")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seqName")
	@SequenceGenerator(name="seqName",sequenceName="str_seq",allocationSize =1)
	@Column(name = "STUDENT_ID")
	private long id;
	@Column(name = "FIRST_NAME")
	private String fname;
	@Column(name = "LAST_NAME")
	private String lname;
	@Column(name = "SECTION")
	private String section;
	
	@OneToOne(mappedBy = "student", cascade = CascadeType.ALL)
	private Address address;
	public Student(){ }
	
	public Student(String fname, String lname, String section) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.section = section;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", fname=" + fname + ", lname=" + lname + ", section=" + section + ", address="
				+ address + "]";
	}
	
}
