package com.lti.jpa.hibernate.model;

import java.time.LocalDate;
import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Orders23")
public class Orders {
	private int OrderID;
	private String OrderName;
	
	private String orderDate;
	private Product product;
	
	public  Orders(){}
	
	public Orders(String orderName, String orderDate) {
		OrderName = orderName;
		this.orderDate = orderDate;
	}
	

	@Id
	@Column(name = "orderid")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="somesequenceName")
	@SequenceGenerator(name="somesequenceName",sequenceName="ord5_seq",allocationSize =1)
	public int getOrderID() {
		return OrderID;
	}
	public void setOrderID(int orderID) {
		OrderID = orderID;
	}
	@Column(name = "ordname")
	public String getOrderName() {
		return OrderName;
	}
	public void setOrderName(String orderName) {
		OrderName = orderName;
	}	
	@Column(name = "orderdate")
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "product_id")
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Orders [OrderID=" + OrderID + ", OrderName=" + OrderName + ", orderDate=" + orderDate + ", product="
				+ product + "]";
	}



	
	
	
	
}
