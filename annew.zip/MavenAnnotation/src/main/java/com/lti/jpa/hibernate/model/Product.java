package com.lti.jpa.hibernate.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Product")
public class Product {
	private long product_id;
	private long product_price;
	private String product_name;
	
	
public Product(){
		
	}


public Product( long product_price, String product_name) {
	
	
	this.product_price = product_price;
	this.product_name = product_name;
}


@Id
@Column(name = "product_id")
@GeneratedValue(strategy=GenerationType.AUTO,generator="somesequenceName")
@SequenceGenerator(name="somesequenceName",sequenceName="product_seq",allocationSize =1)

public long getProduct_id() {
	return product_id;
}
public void setProduct_id(long product_id) {
	this.product_id = product_id;
}

@Column(name = "product_price")
public long getProduct_price() {
	return product_price;
}
public void setProduct_price(long product_price) {
	this.product_price = product_price;
}

@Column(name = "product_name")
public String getProduct_name() {
	return product_name;
}

public void setProduct_name(String product_name) {
	this.product_name = product_name;
}


	
	
}
